
import React from "react";
import { useTranslation } from "react-i18next";

export default function Home() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gradient-to-r from-cyan-400 to-blue-600 text-white flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold mb-4">🌐 Dubaimerx.com</h1>
      <p className="text-lg max-w-xl text-center">{t("home.description")}</p>
    </div>
  );
}
